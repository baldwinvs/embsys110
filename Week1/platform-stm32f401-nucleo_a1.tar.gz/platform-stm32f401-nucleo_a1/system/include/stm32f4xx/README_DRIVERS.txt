This folder is a placeholder where to add vendor provided header files
from the peripheral drivers library.

Study the vendor drivers library and identify the drivers include files.
Copy the files you need in your project to this folder.

It should have been automatically added to the include paths.

If you rename this folder, be sure you also update the include path.
